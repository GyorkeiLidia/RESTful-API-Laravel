<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreCustomerRequest;
use App\Http\Resources\CustomersResource;
use App\Models\Customer;
use App\Traits\HttpResponses;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;


class CustomerController extends Controller
{

    use HttpResponses;

    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return CustomersResource::collection(
            Customer::where('user_id', Auth::user()->id)->get()
        );
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreCustomerRequest $request)
    {
        $request->validated($request->all());

        $customer = Customer::create([

            'user_id' => Auth::user()->id,
            //'customer_id' => Auth::customer()->id,  ///ez nem tuti, hogy jo igy...
            'name' => $request->name,
            'mobil' => $request->mobil
        ]);
        //a create után a user láthatja mit kreált
        return new CustomersResource($customer);
    }

    /**
     * Display the specified resource.
     */
    public function show(Customer $customer) //laravel majd kikeresi a customer-hez való id-t
    {   //ezzel az if-fel a userek csak a saját feladataikat láthatják!
        if(Auth::user()->id !== $customer->user_id){

            return $this->error('', 'You are not authorized.', 403);

        }

        return new CustomersResource($customer); //he csak ennyit irsz, bármelyik user láthatja a másik user feladatait is!
    }

    /**
     * Update the specified resource in storage.
     */ // PUT/PATCH is lehetne, a patch jobb, mert akkor egyetlen sort is lehet updatelni
    public function update(Request $request, Customer $customer)
    {

        if(Auth::user()->id !== $customer->user_id){
            return $this->error('', 'You are not authorized.', 403);
        }

        $customer->update($request->all()); //igy már postmanből update-elünk, de ha
        return new CustomersResource($customer); //csak ezt irjunk, egyik user tudja a 
        //másik userét is update-elni -> kell megint if!!!
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Customer $customer)
    {

        if(Auth::user()->id !== $customer->user_id){
            return $this->error('', 'You are not authorized.', 403);
        }

        $customer->delete();

        return response(null, 204);
    }
}
