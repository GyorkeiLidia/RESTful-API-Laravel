<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreTaskRequest;
use App\Http\Resources\TaskResource;
use App\Http\Resources\TasksResource;
use App\Models\Task;
use App\Traits\HttpResponses;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;


class TasksController extends Controller
{

    use HttpResponses;

    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return TasksResource::collection(
            Task::where('user_id', Auth::user()->id)->get()
        );
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreTaskRequest $request)
    {
        $request->validated($request->all());

        $task = Task::create([

            'user_id' => Auth::user()->id,
            'name' => $request->name,
            'description' => $request->description,
            'priority' => $request->priority
        ]);
        //a create után a user láthatja mit kreált
        return new TasksResource($task);
    }

    /**
     * Display the specified resource.
     */
    public function show(Task $task) //laravel majd kikeresi a task-hez való id-t
    {   //ezzel az if-fel a userek csak a saját feladataikat láthatják!
        if(Auth::user()->id !== $task->user_id){

            return $this->error('', 'You are not authorized.', 403);

        }


        return new TasksResource($task); //he csak ennyit irsz, bármelyik user láthatja a másik user feladatait is!
    }

    /**
     * Update the specified resource in storage.
     */ // PUT/PATCH is lehetne, a patch jobb, mert akkor egyetlen sort is lehet updatelni
    public function update(Request $request, Task $task)
    {

        //csak a lenti sor kéne, ha a function isNotAuthorized-et használnánk
        //return $this->isNotAuthorized($task) ? $this->isNotAuthorized($task) : new TasksResource($task);

        if(Auth::user()->id !== $task->user_id){
            return $this->error('', 'You are not authorized.', 403);
        }

        $task->update($request->all()); //igy már postmanből update-elünk, de ha
        return new TasksResource($task); //csak ezt irjunk, egyik user tudja a 
        //másik userét is update-elni -> kell megint if!!!
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Task $task)
    {

        if(Auth::user()->id !== $task->user_id){
            return $this->error('', 'You are not authorized.', 403);
        }

        $task->delete();

        return response(null, 204);
    }

    /*
    //ez a funkció azért kell, h ne kelljen mindig külön if-et irni arra, hogy
    //a taskban szereplő user_id egyezik-e a user id-val
    private function isNotAuthorized($task){
        if(Auth::user()->id !== $task->user_id){
            return $this->error('', 'You are not authorized.', 403);
        }
    }
    */
}
