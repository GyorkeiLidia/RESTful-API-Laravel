<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class TasksResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => (string)$this->id, //ezzel csak a task id-kat látjuk postmanben
            'attributes' => [
                'name' => $this->name,
                'description' => $this->description,
                'created_at' => $this->created_at,
                'updated_at' => $this->updated_at
            ],
            //lent összekapcsoljuk a két táblázatot, tasks getes kérésnél feladathoz oda irja a user nevét is, emailjét, stb.
            'relationships' => [
                'id' => (string)$this->user->id,
                'user name' => $this->user->name,
                'user email' => $this->user->email,
                'customer' => new CustomersResource($this->whenLoaded('customer')), // assuming 'customer' is the relationship method

            ]
        ];
    }
}
