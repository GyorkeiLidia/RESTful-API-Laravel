<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class CustomersResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => (string)$this->id, //ezzel csak a customer id-kat látjuk postmanben
            'attributes' => [
                'name' => $this->name,
                'mobil' => $this->mobil,
                'created_at' => $this->created_at,
                'updated_at' => $this->updated_at
            ],
            //lent összekapcsoljuk a két táblázatot, customers getes kérésnél feladathoz oda irja a user nevét is, emailjét, stb.
            'relationships' => [
                'id' => (string)$this->user->id,
                'user name' => $this->user->name,
                'user email' => $this->user->email
            ]
        ];
    }

}